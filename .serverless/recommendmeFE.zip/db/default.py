def default():
    return {
        'api': 'Recommend.Me',
        'version': '0.0.1'
    }
